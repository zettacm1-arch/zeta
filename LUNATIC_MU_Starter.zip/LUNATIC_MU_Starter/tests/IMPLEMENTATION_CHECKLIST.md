# Implementation Checklist

## Before coding
- [ ] Receive the exact MUEMU source/config archive and identify its fork/build.
- [ ] Confirm whether the server already compiles and starts without errors.
- [ ] Inventory event manager files and event-specific configuration.
- [ ] Inventory monster/item drop tables and global rate settings.
- [ ] Inventory Zen sources/sinks, Jewel rates, Excellent rates, Chaos Machine formulas.
- [ ] Record current behavior before changing anything.

## Event pass
- [ ] Confirm which events are implemented and enabled.
- [ ] Audit entry fees, rewards, timers, cleanup, disconnect handling, and logs.
- [ ] Add a non-overlapping schedule only after timezone is agreed.
- [ ] Test solo, party, disconnect, event failure, and repeat-claim edge cases.

## Drop/economy pass
- [ ] Verify what “30% drop” means in this fork.
- [ ] Separate Zen, Jewel, Excellent, wing-material, and event drop tuning.
- [ ] Test rates with repeatable controlled runs.
- [ ] Confirm no paid item grants direct or indirect combat/economic advantage.
- [ ] Keep original files and a patch/diff for every change.

## Release gate
- [ ] Clean build succeeds.
- [ ] Test server starts and logs no new errors.
- [ ] Character creation, leveling, reset, trade, storage, and event flows pass.
- [ ] No Master Level / Master Skill Tree features are introduced.
- [ ] Rollback instructions are documented.
