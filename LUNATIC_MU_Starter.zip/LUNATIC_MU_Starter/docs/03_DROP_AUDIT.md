# LUNATIC MU — Drop Audit Specification

## Do not apply “30%” blindly
First identify the exact meaning of the current fork's drop-rate settings. A global rate can unintentionally increase Zen, consumables, jewels, Excellent items, and event drops together.

## Drop categories to audit separately
- Zen
- Basic equipment and consumables
- Jewels (Bless, Soul, Chaos, Life, Creation and any fork-specific items)
- Excellent equipment
- Skill books / class-specific progression items
- Wings and wing materials
- Event-only items
- Boss and invasion drops

## Desired relative outcome
- Common consumables: available through normal farming.
- Jewels: attainable but valuable; avoid excessive drops from repeatable low-risk sources.
- Excellent gear: rare enough to support trading and progression.
- Wings / advanced crafting materials: long-term goals with more than one viable farming route.
- Event rewards: useful without eclipsing ordinary monster farming.

## Required source audit
For each relevant config/table, record: file path, item/monster/event ID, current rate, rate interpretation, proposed rate, expected side effect, test result, and rollback copy. Do not edit IDs or syntax until the actual MUEMU fork files are available.

## Balancing loop
1. Run a controlled farming test with fixed character level, map, duration, and party size.
2. Count drops by category and normalize per player-hour.
3. Repeat on at least two representative maps and one event.
4. Compare results against the economy targets.
5. Change one category at a time and rerun the test.
