# LUNATIC MU — Event Plan (Draft for Testing)

This is a scheduling and reward-design proposal, not a claim about the default MUEMU timers. Exact event names, availability, and config fields must be confirmed in the supplied source.

## Event principles
- Events should be predictable, announced, and spread across the day.
- Avoid scheduling major events to start at the same time.
- Rewards should emphasize participation, useful materials, and moderate Zen rather than guaranteed top-tier gear.
- Rare rewards should be chance-based and monitored; no event should become the only rational way to farm.
- Keep PvP rewards fair and avoid rewards that snowball the strongest guild indefinitely.

## Candidate event review
| Event | Review focus | Reward direction | Risk to monitor |
|---|---|---|---|
| Blood Castle | Entry requirements, duration, completion logic | Moderate Zen/materials; limited chance at useful items | Repeated runs flooding materials |
| Devil Square | Monster density, score and reward logic | EXP-focused plus modest material rewards | EXP event undermining progression balance |
| Chaos Castle | Entry fee, winner reward, class fairness | Competitive reward with capped economic value | Strong players farming rewards uncontested |
| Golden Invasion | Spawn count, map coverage, drop tables | Rare but controlled drops | Golden drops becoming the dominant income source |
| Boss / custom invasions | Spawn schedule, HP/damage, contribution rules | Group-focused materials and prestige rewards | Kill stealing and guild monopolies |
| Castle Siege (if enabled) | Tax, guild rewards, reset cadence | Strategic rewards with economic caps | Permanent wealth advantage for one guild |

## Scheduling template
Do not publish times until the server timezone and actual event configuration are verified. Use a rotating schedule with at least 30 minutes between major event start times where possible. Publish timezone explicitly (for example, UTC) and keep announcements consistent.

## Test checklist per event
1. Can eligible characters enter and leave correctly?
2. Are maps, monsters, and gates reset after completion/failure?
3. Can a player claim a reward more than once from one run?
4. Are rewards granted if the player disconnects or the event ends unexpectedly?
5. Can party/guild mechanics be abused to multiply rewards?
6. Do logs identify winner, participants, and rewards?
7. Does the reward rate remain sustainable over a 7-day simulated economy test?
