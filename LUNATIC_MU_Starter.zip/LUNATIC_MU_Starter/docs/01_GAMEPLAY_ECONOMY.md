# LUNATIC MU — Gameplay & Economy Baseline

## 1. Progression philosophy
LUNATIC MU is built around **fast leveling, difficult wealth progression**. EXP x2000 should reduce repetitive leveling, not make valuable equipment, Zen, Jewels, wings, or upgrades trivial to obtain.

## 2. Server baseline
| Setting | Target |
|---|---:|
| Client/server version | Season 3 Episode 1 |
| Base EXP | x2000 |
| Item drop target | 30% (must be verified against the MUEMU fork's rate semantics) |
| Maximum character level | 400 |
| Maximum stat value | 32767 |
| Maximum resets | 9999 |
| Master Level / Master Skill Tree | Disabled / not present |

**Rate warning:** “30% drop” can mean different things in different MUEMU forks. Before editing, identify whether the server uses a global item-drop multiplier, per-monster rates, separate Excellent/Jewel rates, or a combination. Do not apply a blind global multiplier.

## 3. Economy principles
- Zen must have meaningful sinks: NPC purchases, repair, travel/utility costs, reset costs, and selected crafting/upgrading fees, balanced to avoid punishing new players.
- Jewels should retain value through upgrade demand and controlled supply.
- Excellent items should be a progression milestone, not routine trash drops.
- Wings and high-end upgrades should require a meaningful mix of farming, materials, and Zen.
- Event rewards should complement normal farming, not replace it.
- Avoid guaranteed high-value rewards on short, repeatable timers.

## 4. Telemetry to collect before tuning
Record at minimum: Zen earned/spent per active hour, Jewel drops per player-hour, Excellent items per player-hour, event participation, Chaos Machine attempts/successes, and market prices for core materials. Tune from test data rather than intuition alone.

## 5. No Pay-to-Win rule
Cosmetics may be sold if they do not change combat stats, drop chances, crafting odds, progression speed, or access to exclusive power. Any convenience item must be reviewed for indirect economic advantage before release.
