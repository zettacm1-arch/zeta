# LUNATIC MU — Systems Starter Pack

**Target:** MUEMU · Season 3 Episode 1  
**Design:** fast leveling, hard economy, long-term progression, grind and win  
**Core settings:** EXP x2000 · item drop target 30% · max level 400 · max stats 32767 · max 9999 resets  
**Excluded:** Master Level and Master Skill Tree  
**Monetization:** no Pay-to-Win; shop items should be cosmetic/convenience only and must not grant combat stats or exclusive power.

## Important
This pack is the first design/configuration baseline, not a drop-in MUEMU patch. MUEMU forks use different file layouts, config keys, event implementations, and drop formats. Do not copy these templates over live server files. Once the actual server source/configuration archive is supplied, map these rules to the exact files and produce a version-specific patch.

## Work order
1. Inventory the exact MUEMU source and configuration files.
2. Map current event timers, event rewards, monster/item drops, Zen sources/sinks, jewel rates, and Chaos Machine rates.
3. Implement one change at a time with original files preserved.
4. Build and test on a private test server before deployment.

## Initial acceptance criteria
- No event rewards directly flood the economy with high-tier gear or large amounts of Zen.
- Jewels and Excellent items remain valuable and tradable.
- Event schedule avoids overlaps and gives players clear, predictable opportunities.
- All configurable rates are documented in one place where the fork permits it.
- No Master Level / Master Skill Tree dependencies are introduced.
- No paid item grants direct PvP or progression advantage.
